import argparse
import os
import sys
import logging
from typing import Iterable, Dict, List, Any, Optional
import re
from datetime import datetime

import easyocr
import torch
import numpy as np
from PIL import Image
import json


def extract_dates(text: str) -> List[str]:
    """Extract dates in various formats from text"""
    date_patterns = [
        r'\d{1,2}[-/.]\d{1,2}[-/.]\d{4}',  # DD-MM-YYYY, DD/MM/YYYY, DD.MM.YYYY
        r'\d{4}[-/.]\d{1,2}[-/.]\d{1,2}',  # YYYY-MM-DD, YYYY/MM/DD, YYYY.MM.DD
        r'\d{1,2}\s+\w+\s+\d{4}',         # DD Month YYYY
        r'\w+\s+\d{1,2},?\s+\d{4}'        # Month DD, YYYY
    ]
    
    dates = []
    for pattern in date_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        dates.extend(matches)
    
    return list(set(dates))  # Remove duplicates


def extract_parties(text: str) -> List[Dict[str, str]]:
    """Extract party information from legal documents"""
    parties = []
    
    # Look for company names (usually in caps or with specific keywords)
    company_patterns = [
        r'([A-Z][A-Z\s&]+(?:LIMITED|LTD|PRIVATE|PVT|COMPANY|CORP|CORPORATION|INC))',
        r'([A-Z][A-Z\s&]+(?:LLC|LLP))'
    ]
    
    for pattern in company_patterns:
        matches = re.findall(pattern, text)
        for match in matches:
            if len(match.strip()) > 5:  # Filter out very short matches
                parties.append({
                    "name": match.strip(),
                    "address": "",
                    "phone": "",
                    "email": "",
                    "CIN": "",
                    "PAN": "",
                    "GST": "",
                    "obligations": []
                })
    
    return parties


def extract_addresses(text: str) -> List[str]:
    """Extract addresses from text"""
    # Look for patterns that typically indicate addresses
    address_patterns = [
        r'(?:residing at|located at|address[:\s]+)([^,\n]+(?:,[^,\n]+)*)',
        r'(\d+[^,\n]*(?:Road|Street|Avenue|Lane|Building|Floor)[^,\n]*(?:,[^,\n]+)*)',
        r'([A-Z][^,\n]*(?:Gujarat|Mumbai|Delhi|Bangalore|Chennai|Kolkata|Hyderabad)[^,\n]*)'
    ]
    
    addresses = []
    for pattern in address_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        addresses.extend(matches)
    
    return list(set(addresses))


def extract_amounts(text: str) -> List[str]:
    """Extract monetary amounts from text"""
    amount_patterns = [
        r'(?:Rs\.?|Rupees)\s*([0-9,]+(?:\.[0-9]+)?)',
        r'([0-9,]+(?:\.[0-9]+)?)\s*(?:Rs\.?|Rupees)',
        r'(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)\s*(?:only|/-)'
    ]
    
    amounts = []
    for pattern in amount_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        amounts.extend(matches)
    
    return list(set(amounts))


def extract_clauses(text: str) -> List[Dict[str, Any]]:
    """Extract numbered clauses from legal documents"""
    clauses = []
    
    # Pattern to match numbered clauses
    clause_pattern = r'(\d+(?:\.\d+)?)\.\s*([^0-9]+?)(?=\d+\.|$)'
    matches = re.findall(clause_pattern, text, re.DOTALL)
    
    for clause_num, clause_text in matches:
        if len(clause_text.strip()) > 20:  # Filter out very short clauses
            clauses.append({
                "clauseNumber": clause_num,
                "description": clause_text.strip()[:100] + "..." if len(clause_text.strip()) > 100 else clause_text.strip(),
                "clauseText": clause_text.strip(),
                "references": []
            })
    
    return clauses


def extract_case_info(text: str) -> Dict[str, str]:
    """Extract case/application information"""
    case_info = {}
    
    # Extract case numbers
    case_patterns = [
        r'(?:CIVIL MISC\.?\s*APP\.?\s*NO\.?\s*)([0-9/]+)',
        r'(?:Case No\.?\s*)([0-9/]+)',
        r'(?:Application No\.?\s*)([0-9/]+)'
    ]
    
    for pattern in case_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            case_info["caseNumber"] = match.group(1)
            break
    
    # Extract court information
    court_pattern = r'(?:IN THE COURT OF|COURT OF)\s+([^,\n]+)'
    court_match = re.search(court_pattern, text, re.IGNORECASE)
    if court_match:
        case_info["court"] = court_match.group(1).strip()
    
    return case_info


def analyze_document_structure(all_text: str) -> Dict[str, Any]:
    """Analyze the complete document and extract structured information"""
    
    # Determine document type
    doc_type = "Unknown"
    if "agreement" in all_text.lower() or "contract" in all_text.lower():
        doc_type = "Contract/Agreement"
    elif "application" in all_text.lower() and "court" in all_text.lower():
        doc_type = "Legal Application"
    elif "suit" in all_text.lower() or "petition" in all_text.lower():
        doc_type = "Legal Suit/Petition"
    
    extracted_data = {
        "documentType": doc_type,
        "extractedDates": extract_dates(all_text),
        "extractedParties": extract_parties(all_text),
        "extractedAddresses": extract_addresses(all_text),
        "extractedAmounts": extract_amounts(all_text),
        "extractedClauses": extract_clauses(all_text),
        "caseInformation": extract_case_info(all_text),
        "rawText": all_text
    }
    
    # For legal applications, try to extract specific fields
    if doc_type == "Legal Application":
        extracted_data.update(extract_legal_application_fields(all_text))
    elif doc_type == "Contract/Agreement":
        extracted_data.update(extract_contract_fields(all_text))
    
    return extracted_data


def extract_legal_application_fields(text: str) -> Dict[str, Any]:
    """Extract specific fields for legal applications"""
    fields = {}
    
    # Extract applicant information
    applicant_pattern = r'Applicant[s]?[:\s]*([^v\n]+?)(?=Versus|VERSUS|V/s)'
    applicant_match = re.search(applicant_pattern, text, re.IGNORECASE | re.DOTALL)
    if applicant_match:
        fields["applicants"] = applicant_match.group(1).strip()
    
    # Extract property information
    property_patterns = [
        r'(?:survey no\.?\s*)([0-9,\s]+)',
        r'(?:bearing.*?survey no\.?\s*)([0-9,\s]+)',
        r'(?:admeasuring\s*)([0-9\-\s]+(?:Hectare|Acre))'
    ]
    
    for pattern in property_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            if "surveyNumber" not in fields:
                fields["surveyNumber"] = match.group(1).strip()
            elif "area" not in fields:
                fields["area"] = match.group(1).strip()
    
    # Extract village/location information
    village_pattern = r'(?:Village|Taluka)\s+([^,\n]+)'
    village_matches = re.findall(village_pattern, text, re.IGNORECASE)
    if village_matches:
        fields["location"] = ", ".join(set(village_matches))
    
    return fields


def extract_contract_fields(text: str) -> Dict[str, Any]:
    """Extract specific fields for contracts/agreements"""
    fields = {}
    
    # Extract agreement dates
    agreement_date_pattern = r'(?:dated|agreement.*?dated|executed on)\s*([0-9\-/.]+)'
    date_match = re.search(agreement_date_pattern, text, re.IGNORECASE)
    if date_match:
        fields["agreementDate"] = date_match.group(1)
    
    # Extract jurisdiction
    jurisdiction_pattern = r'(?:jurisdiction of|courts at)\s+([^,\n.]+)'
    jurisdiction_match = re.search(jurisdiction_pattern, text, re.IGNORECASE)
    if jurisdiction_match:
        fields["jurisdiction"] = jurisdiction_match.group(1).strip()
    
    # Extract termination clauses
    termination_pattern = r'(terminate.*?agreement.*?)(?=\.|;|\n)'
    termination_matches = re.findall(termination_pattern, text, re.IGNORECASE | re.DOTALL)
    if termination_matches:
        fields["terminationClauses"] = termination_matches
    
    return fields


def pdf_to_images_fitz(path: str, dpi: int = 200) -> Iterable[Image.Image]:
    try:
        import fitz
    except Exception:
        raise

    doc = fitz.open(path)
    for page in doc:
        pix = page.get_pixmap(dpi=dpi)
        mode = "RGBA" if pix.alpha else "RGB"
        img = Image.frombytes(mode, (pix.width, pix.height), pix.samples)
        if mode == "RG        python ocr.py Suit-Damayanti.pdf --cpu --dpi 300 --output results.jsonBA":
            img = img.convert("RGB")
        yield img


def pdf_to_images_pdf2image(path: str, dpi: int = 200) -> Iterable[Image.Image]:
    from pdf2image import convert_from_path

    pages = convert_from_path(path, dpi=dpi)
    for p in pages:
        yield p.convert("RGB")


def load_images(path: str, dpi: int = 200) -> Iterable[Image.Image]:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        # Prefer PyMuPDF (fitz), fallback to pdf2image
        try:
            yield from pdf_to_images_fitz(path, dpi=dpi)
            return
        except Exception:
            try:
                yield from pdf_to_images_pdf2image(path, dpi=dpi)
                return
            except Exception as e:
                raise RuntimeError(
                    "Can't convert PDF to images. Install PyMuPDF (`pip install pymupdf`) or pdf2image + poppler." +
                    f" Original error: {e}"
                )
    else:
        # Single image file
        img = Image.open(path).convert("RGB")
        yield img


def main():
    parser = argparse.ArgumentParser(description="OCR images or PDFs using EasyOCR with structured extraction")
    parser.add_argument("input", help="Path to image or PDF file")
    parser.add_argument("--dpi", type=int, default=200, help="DPI for PDF rendering (default: 200)")
    parser.add_argument("--cpu", action="store_true", help="Force CPU (disable GPU even if available)")
    parser.add_argument("--lang", default="en", help="Language(s) for EasyOCR (comma-separated)")
    parser.add_argument("--output", "-o", help="Output JSON file path (default: <input>.json)")
    parser.add_argument("--simple", action="store_true", help="Use simple text extraction (original format)")
    args = parser.parse_args()

    # Use GPU by default if available, unless --cpu flag is specified
    use_gpu = torch.cuda.is_available() and not args.cpu
    
    if torch.cuda.is_available():
        print(f"CUDA available: Using {'GPU' if use_gpu else 'CPU (forced by --cpu flag)'}")
    else:
        print("CUDA not available: Using CPU")
        use_gpu = False

    logging.info(f"Initializing EasyOCR reader (gpu={use_gpu})")
    reader = easyocr.Reader([l.strip() for l in args.lang.split(',') if l.strip()], gpu=use_gpu)

    path = args.input
    if not os.path.exists(path):
        print(f"Input path does not exist: {path}")
        sys.exit(2)

    pages_output = []
    all_text = ""

    for page_no, img in enumerate(load_images(path, dpi=args.dpi), start=1):
        img_np = np.array(img)
        results = reader.readtext(img_np)
        print(f"--- Page {page_no} — {len(results)} detections ---")

        detections = []
        page_text = ""
        
        for bbox, text, prob in results:
            detections.append(text)
            page_text += text + " "
            print(f"Page {page_no}: {text} (conf={prob:.2f})")

        all_text += page_text + "\n"
        
        pages_output.append({
            "page": page_no,
            "detections": detections,
            "text": page_text.strip()
        })

    # Write output JSON
    out_path: Optional[str] = args.output
    if not out_path:
        base, _ = os.path.splitext(path)
        out_path = base + ".json"

    if args.simple:
        # Original simple format
        out_data = {
            "input": os.path.abspath(path),
            "pages": pages_output
        }
    else:
        # Enhanced structured format
        structured_data = analyze_document_structure(all_text)
        out_data = {
            "input": os.path.abspath(path),
            "extractionTimestamp": datetime.now().isoformat(),
            "pages": pages_output,
            "Extracted": structured_data
        }

    try:
        with open(out_path, "w", encoding="utf-8") as fh:
            json.dump(out_data, fh, ensure_ascii=False, indent=2)
        print(f"Wrote OCR results to: {out_path}")
        
        if not args.simple:
            print(f"Document Type: {structured_data.get('documentType', 'Unknown')}")
            print(f"Extracted {len(structured_data.get('extractedDates', []))} dates")
            print(f"Extracted {len(structured_data.get('extractedParties', []))} parties")
            print(f"Extracted {len(structured_data.get('extractedClauses', []))} clauses")
            
    except Exception as e:
        print(f"Failed to write JSON output: {e}")


if __name__ == "__main__":
    main()
