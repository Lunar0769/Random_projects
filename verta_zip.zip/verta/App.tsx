import React, { useState } from 'react';
import { Mic, Zap, Github, AlertTriangle } from 'lucide-react';
import FileUpload from './components/FileUpload';
import Dashboard from './components/Dashboard';
import { AppState, AnalysisResult, FileData } from './types';
import { readFileAsBase64, formatFileSize } from './utils/fileUtils';
import { analyzeMeeting } from './services/geminiService';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [currentFile, setCurrentFile] = useState<FileData | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleFileSelect = async (file: File) => {
    try {
      setAppState(AppState.UPLOADING);
      setErrorMsg(null);
      
      // Show different messages for large files
      if (file.size > 15 * 1024 * 1024) {
        setErrorMsg("Large file detected. This may take 1-2 minutes to process...");
      }
      
      const fileData = await readFileAsBase64(file);
      setCurrentFile(fileData);
      
      setAppState(AppState.ANALYZING);
      const result = await analyzeMeeting(fileData);
      
      setAnalysisResult(result);
      setAppState(AppState.SUCCESS);
    } catch (err: any) {
      console.error(err);
      setAppState(AppState.ERROR);
      setErrorMsg(err.message || "An unexpected error occurred during analysis.");
    }
  };

  const resetApp = () => {
    setAppState(AppState.IDLE);
    setAnalysisResult(null);
    setCurrentFile(null);
    setErrorMsg(null);
  };

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-50 selection:bg-blue-500/30">
      
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-lg border-b border-slate-800 bg-[#0f172a]/80">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={resetApp}>
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-xl tracking-tight">VERTA</h1>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-6">
             <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20">
               <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                </span>
               <span className="text-xs font-medium text-blue-400">Powered by Gemini 2.5 Flash</span>
             </div>
             <a href="https://github.com/Lunar0769" className="text-slate-400 hover:text-white transition-colors">
               <Github className="w-5 h-5" />
             </a>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        {/* Hero / Upload State */}
        {appState === AppState.IDLE && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-8 animate-in slide-in-from-bottom-4 duration-700">
            <div className="space-y-4 max-w-2xl">
              <h2 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-purple-400 to-blue-400 pb-2">
                Uncover insights from your meetings.
              </h2>
              <p className="text-lg text-slate-400">
                Upload your audio or video recording. VERTA uses Gemini 2.5 Flash to infer speakers, analyze sentiment, and extract action items in seconds.
              </p>
            </div>
            
            <FileUpload onFileSelect={handleFileSelect} isProcessing={false} />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12 text-left max-w-4xl w-full">
               <div className="p-4 rounded-xl bg-slate-800/30 border border-slate-800">
                 <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center mb-3">
                   <Mic className="w-5 h-5 text-blue-400" />
                 </div>
                 <h3 className="font-semibold text-slate-200 mb-1">Smart Transcription</h3>
                 <p className="text-sm text-slate-500">Multimodal processing understands context better than standard STT.</p>
               </div>
               <div className="p-4 rounded-xl bg-slate-800/30 border border-slate-800">
                 <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center mb-3">
                   <Zap className="w-5 h-5 text-purple-400" />
                 </div>
                 <h3 className="font-semibold text-slate-200 mb-1">Instant Insights</h3>
                 <p className="text-sm text-slate-500">Get engagement scores, summaries, and action items in one go.</p>
               </div>
               <div className="p-4 rounded-xl bg-slate-800/30 border border-slate-800">
                 <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center mb-3">
                   <AlertTriangle className="w-5 h-5 text-emerald-400" />
                 </div>
                 <h3 className="font-semibold text-slate-200 mb-1">Privacy First</h3>
                 <p className="text-sm text-slate-500">Files are processed in memory and not stored. Secure by design.</p>
               </div>
            </div>
          </div>
        )}

        {/* Processing State */}
        {(appState === AppState.UPLOADING || appState === AppState.ANALYZING) && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-8 animate-in fade-in duration-500">
             <div className="relative">
               <div className="absolute inset-0 bg-blue-500 blur-xl opacity-20 rounded-full animate-pulse"></div>
               <div className="relative w-24 h-24 rounded-full border-4 border-blue-500/30 border-t-blue-500 animate-spin"></div>
             </div>
             <div className="space-y-2">
               <h2 className="text-2xl font-bold text-slate-100">
                 {appState === AppState.UPLOADING ? 'Preparing Media...' : 'Gemini is Analyzing...'}
               </h2>
               <p className="text-slate-400">
                 {appState === AppState.UPLOADING 
                   ? 'Reading file into memory.' 
                   : 'Detecting speakers, analyzing tone, and extracting insights.'}
               </p>
               {currentFile && (
                 <p className="text-xs text-slate-500 font-mono mt-4">
                   {currentFile.name} ({formatFileSize(currentFile.size)})
                 </p>
               )}
             </div>
          </div>
        )}

        {/* Error State */}
        {appState === AppState.ERROR && (
          <div className="flex flex-col items-center justify-center min-h-[50vh] text-center space-y-6 animate-in zoom-in-95 duration-300">
            <div className="p-6 rounded-full bg-red-500/10 text-red-400 ring-1 ring-red-500/20">
              <AlertTriangle className="w-12 h-12" />
            </div>
            <div className="max-w-md space-y-2">
              <h3 className="text-xl font-bold text-slate-100">Analysis Failed</h3>
              <p className="text-slate-400">{errorMsg}</p>
            </div>
            <button 
              onClick={resetApp}
              className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors border border-slate-700"
            >
              Try Again
            </button>
          </div>
        )}

        {/* Success / Dashboard State */}
        {appState === AppState.SUCCESS && analysisResult && (
           <div className="space-y-6">
             <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
               <div>
                 <h2 className="text-2xl font-bold text-slate-100 mb-1">Analysis Results</h2>
                 <p className="text-slate-400 text-sm flex items-center gap-2">
                   File: {currentFile?.name} 
                   <span className="w-1 h-1 rounded-full bg-slate-600"></span>
                   Size: {currentFile ? formatFileSize(currentFile.size) : ''}
                 </p>
               </div>
               <button 
                onClick={resetApp}
                className="px-4 py-2 text-sm bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors border border-slate-700"
               >
                 Analyze Another
               </button>
             </div>
             
             <Dashboard result={analysisResult} />
           </div>
        )}

      </main>
    </div>
  );
};

export default App;
