import React from 'react';
import { Summary } from '../types';
import { CheckCircle2, Target, HelpCircle, Activity } from 'lucide-react';

interface SummaryCardProps {
  summary: Summary;
}

const SummaryCard: React.FC<SummaryCardProps> = ({ summary }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="space-y-6">
        {/* Key Points */}
        <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700 h-full">
          <h3 className="text-lg font-semibold text-slate-100 mb-4 flex items-center gap-2">
            <Target className="w-5 h-5 text-blue-400" />
            Key Points
          </h3>
          <ul className="space-y-3">
            {summary.key_points.map((point, idx) => (
              <li key={idx} className="flex items-start gap-3 text-slate-300 text-sm">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-2 flex-shrink-0" />
                {point}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="space-y-6">
        {/* Decisions & Effectiveness */}
        <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <h3 className="text-lg font-semibold text-slate-100 mb-4 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            Decisions & Outcomes
          </h3>
          <ul className="space-y-3 mb-6">
            {summary.decisions.length > 0 ? (
              summary.decisions.map((decision, idx) => (
                <li key={idx} className="flex items-start gap-3 text-slate-300 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                  {decision}
                </li>
              ))
            ) : (
              <li className="text-slate-500 text-sm italic">No explicit decisions detected.</li>
            )}
          </ul>
          
          <div className="p-4 rounded-lg bg-slate-900/30 border border-slate-700/50">
             <div className="flex items-center gap-2 mb-2">
               <Activity className="w-4 h-4 text-indigo-400" />
               <span className="text-xs font-semibold text-indigo-300 uppercase tracking-wider">Meeting Effectiveness</span>
             </div>
             <p className="text-sm text-slate-300 leading-relaxed">{summary.meeting_effectiveness}</p>
          </div>
        </div>

        {/* Open Questions */}
        {summary.open_questions.length > 0 && (
          <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
            <h3 className="text-lg font-semibold text-slate-100 mb-4 flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-orange-400" />
              Open Questions
            </h3>
            <ul className="space-y-3">
              {summary.open_questions.map((q, idx) => (
                <li key={idx} className="flex items-start gap-3 text-slate-300 text-sm">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-400 mt-2 flex-shrink-0" />
                  {q}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};

export default SummaryCard;
