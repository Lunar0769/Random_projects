import React from 'react';
import { TranscriptionItem } from '../types';
import { MessageSquare, ThumbsUp, ThumbsDown, Minus, Tag } from 'lucide-react';

interface TimelineProps {
  segments: TranscriptionItem[];
}

const Timeline: React.FC<TimelineProps> = ({ segments }) => {
  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment?.toLowerCase()) {
      case 'positive': return <ThumbsUp className="w-3 h-3 text-green-400" />;
      case 'negative': return <ThumbsDown className="w-3 h-3 text-red-400" />;
      default: return <Minus className="w-3 h-3 text-slate-400" />;
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment?.toLowerCase()) {
      case 'positive': return 'text-green-400 border-green-400/20 bg-green-400/5';
      case 'negative': return 'text-red-400 border-red-400/20 bg-red-400/5';
      default: return 'text-slate-400 border-slate-400/20 bg-slate-400/5';
    }
  };

  return (
    <div className="space-y-6 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-slate-700 before:to-transparent">
      {segments.map((segment, idx) => (
        <div key={idx} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
          
          {/* Icon/Dot */}
          <div className="flex items-center justify-center w-10 h-10 rounded-full border border-slate-700 bg-slate-800 group-hover:bg-blue-500/10 group-hover:border-blue-500/50 transition-colors shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 text-slate-400">
            <MessageSquare className="w-5 h-5" />
          </div>
          
          {/* Card */}
          <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-slate-800/50 border border-slate-700 p-4 rounded-xl shadow-sm transition-all hover:shadow-md hover:border-slate-600">
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                   <span className="font-bold text-blue-400 text-sm">{segment.speaker}</span>
                   <span className="text-xs text-slate-500 font-mono bg-slate-900/50 px-2 py-0.5 rounded">{segment.approx_timestamp}</span>
                </div>
                <div className={`flex items-center gap-1.5 text-xs px-2 py-1 rounded-full border ${getSentimentColor(segment.sentiment.label)}`}>
                    {getSentimentIcon(segment.sentiment.label)}
                    <span className="uppercase tracking-wider font-semibold">{segment.sentiment.label}</span>
                </div>
              </div>
              
              <p className="text-slate-300 text-sm leading-relaxed">
                {segment.text}
              </p>

              <div className="pt-3 border-t border-slate-700/50 flex flex-col sm:flex-row gap-3 text-xs">
                 <div className="flex items-center gap-1.5 text-slate-400 bg-slate-900/30 px-2 py-1 rounded">
                   <Tag className="w-3 h-3" />
                   {segment.topic}
                 </div>
                 {segment.sentiment.explanation && (
                   <div className="text-slate-500 italic flex-1 border-l border-slate-700 pl-3">
                     {segment.sentiment.explanation}
                   </div>
                 )}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Timeline;
