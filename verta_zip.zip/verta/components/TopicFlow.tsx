import React from 'react';
import { TopicFlowItem } from '../types';
import { ArrowRight, Clock } from 'lucide-react';

interface TopicFlowProps {
  flow: TopicFlowItem[];
}

const TopicFlow: React.FC<TopicFlowProps> = ({ flow }) => {
  if (!flow || flow.length === 0) return null;

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700 p-6">
      <h3 className="text-lg font-semibold text-slate-100 mb-6 flex items-center gap-2">
        <Clock className="w-5 h-5 text-purple-400" />
        Topic Progression
      </h3>
      <div className="relative space-y-8">
        {/* Vertical Line */}
        <div className="absolute left-[19px] top-4 bottom-4 w-0.5 bg-slate-700/50"></div>

        {flow.map((item, idx) => (
          <div key={idx} className="relative flex gap-4 group">
            {/* Dot */}
            <div className="relative z-10 flex-shrink-0 w-10 h-10 rounded-full bg-slate-800 border-2 border-slate-600 flex items-center justify-center group-hover:border-purple-500 group-hover:bg-purple-500/10 transition-colors">
              <span className="text-xs font-bold text-slate-400 group-hover:text-purple-400">{idx + 1}</span>
            </div>

            <div className="flex-1 bg-slate-800/80 border border-slate-700/50 rounded-lg p-4 hover:border-purple-500/30 transition-colors">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-slate-200">{item.topic}</h4>
                <div className="text-xs font-mono text-slate-500 bg-slate-900/50 px-2 py-1 rounded">
                  {item.start} - {item.end}
                </div>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed border-l-2 border-purple-500/20 pl-3">
                {item.reasoning}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TopicFlow;
