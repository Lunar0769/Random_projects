export interface Sentiment {
  label: 'positive' | 'neutral' | 'negative';
  explanation: string;
}

export interface TranscriptionItem {
  approx_timestamp: string;
  speaker: string;
  text: string;
  sentiment: Sentiment;
  topic: string;
}

export interface TopicFlowItem {
  topic: string;
  start: string;
  end: string;
  reasoning: string;
}

export interface EngagementAnalysis {
  score: number;
  trend: 'rising' | 'falling' | 'stable';
  explanation: string;
}

export interface EngagementTrend {
  time: string;
  score: number;
}

export interface Summary {
  key_points: string[];
  decisions: string[];
  open_questions: string[];
  meeting_effectiveness: string;
}

export interface ActionItem {
  task: string;
  owner: string;
  priority: 'high' | 'medium' | 'low';
  timeline: 'short-term' | 'long-term' | 'unspecified';
}

export interface Metadata {
  duration_minutes: number;
  analysis_depth: 'high' | 'medium' | 'low';
  confidence_notes: string;
}

export interface AnalysisResult {
  metadata: Metadata;
  transcription: TranscriptionItem[];
  topic_flow: TopicFlowItem[];
  engagement_analysis: EngagementAnalysis;
  summary: Summary;
  action_items: ActionItem[];
  improvement_suggestions: string[];
}

export enum AppState {
  IDLE = 'IDLE',
  UPLOADING = 'UPLOADING',
  ANALYZING = 'ANALYZING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}

export interface FileData {
  name: string;
  size: number;
  type: string;
  base64: string;
}