import { FileData } from '../types';

export const readFileAsBase64 = (file: File): Promise<FileData> => {
  return new Promise(async (resolve, reject) => {
    try {
      let processedFile = file;
      
      // For large files (>15MB), show processing message
      if (file.size > 15 * 1024 * 1024) {
        console.log(`Large file detected (${formatFileSize(file.size)}). Processing...`);
        processedFile = await compressFile(file);
      }
      
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        // Remove data URL prefix (e.g., "data:audio/mp3;base64,")
        const base64 = result.split(',')[1];
        resolve({
          name: processedFile.name,
          size: processedFile.size,
          type: processedFile.type,
          base64: base64,
        });
      };
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(processedFile);
    } catch (error) {
      reject(error);
    }
  });
};

const compressFile = async (file: File): Promise<File> => {
  // For audio files, we can't easily compress in browser without losing quality
  // So we'll just return the original file but add a warning
  console.log("Note: Large file processing may take longer and use more memory.");
  return file;
};

export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const cleanJsonResponse = (text: string): string => {
  let cleanText = text.trim();
  
  // Remove markdown code blocks if present
  if (cleanText.startsWith('```json')) {
    cleanText = cleanText.replace(/^```json\s*/, '').replace(/\s*```$/, '');
  } else if (cleanText.startsWith('```')) {
    cleanText = cleanText.replace(/^```\s*/, '').replace(/\s*```$/, '');
  }
  
  // Try to extract JSON from anywhere in the text
  const jsonMatch = cleanText.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    cleanText = jsonMatch[0];
  }
  
  return cleanText;
};

export const extractJsonFromText = (text: string): string | null => {
  // Multiple strategies to extract JSON
  const strategies = [
    // Strategy 1: Find complete JSON object
    () => {
      const match = text.match(/\{[\s\S]*\}/);
      return match ? match[0] : null;
    },
    
    // Strategy 2: Find JSON between specific markers
    () => {
      const patterns = [
        /```json\s*(\{[\s\S]*?\})\s*```/,
        /```\s*(\{[\s\S]*?\})\s*```/,
        /JSON:\s*(\{[\s\S]*?\})/i,
        /Response:\s*(\{[\s\S]*?\})/i
      ];
      
      for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match && match[1]) return match[1];
      }
      return null;
    },
    
    // Strategy 3: Find the largest valid JSON object
    () => {
      const openBraces = [];
      let start = -1;
      let maxLength = 0;
      let bestJson = null;
      
      for (let i = 0; i < text.length; i++) {
        if (text[i] === '{') {
          if (start === -1) start = i;
          openBraces.push(i);
        } else if (text[i] === '}' && openBraces.length > 0) {
          openBraces.pop();
          if (openBraces.length === 0) {
            const candidate = text.substring(start, i + 1);
            if (candidate.length > maxLength) {
              try {
                JSON.parse(candidate);
                maxLength = candidate.length;
                bestJson = candidate;
              } catch (e) {
                // Invalid JSON, continue
              }
            }
            start = -1;
          }
        }
      }
      
      return bestJson;
    }
  ];
  
  for (const strategy of strategies) {
    try {
      const result = strategy();
      if (result) {
        // Validate it's proper JSON
        JSON.parse(result);
        return result;
      }
    } catch (e) {
      continue;
    }
  }
  
  return null;
};
